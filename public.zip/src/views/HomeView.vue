<template>
  <div class="bg-gray-50">
    
    <section class="flex flex-col items-center justify-center bg-blue-600 text-white py-16">
      <h1 class="text-4xl font-bold mb-4">Olá, meu nome é João Pedro</h1>
      <p class="text-lg max-w-2xl text-center mb-6">Sou um desenvolvedor front-end apaixonado por criar experiências incríveis na web. </p>
      <router-link to="/contato" class="bg-blue-800 text-white py-2 px-6 rounded hover:bg-blue-700">Entre em contato</router-link>
    </section>

    
    <section class="py-16 px-4 bg-white">
      <h2 class="text-3xl font-semibold text-center mb-8">Minhas Habilidades</h2>
      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <div class="text-center bg-gray-100 p-6 rounded-lg shadow-lg">
          <p class="font-semibold">Vue.js</p>
        </div>
        <div class="text-center bg-gray-100 p-6 rounded-lg shadow-lg">
          <p class="font-semibold">JavaScript</p>
        </div>
        <div class="text-center bg-gray-100 p-6 rounded-lg shadow-lg">
          <p class="font-semibold">HTML5</p>
        </div>
        <div class="text-center bg-gray-100 p-6 rounded-lg shadow-lg">
          <p class="font-semibold">CSS3</p>
        </div>
        <div class="text-center bg-gray-100 p-6 rounded-lg shadow-lg">
          <p class="font-semibold">Tailwind CSS</p>
        </div>
        <div class="text-center bg-gray-100 p-6 rounded-lg shadow-lg">
          <p class="font-semibold">Git</p>
        </div>
      </div>
    </section>

    
    <section class="py-16 px-4 bg-gray-200">
      <h2 class="text-3xl font-semibold text-center mb-8">Minha Trajetória</h2>
      <div class="max-w-4xl mx-auto space-y-6">
        <div class="flex items-center justify-between">
          <div class="flex-1 p-6 bg-white shadow-md rounded-lg">
            <h3 class="font-semibold text-xl">Desenvolvedor Front-End</h3>
            <p class="text-gray-700">Empresa XYZ - Jan 2022 - Presente</p>
            <p class="mt-4">Trabalho no desenvolvimento de interfaces com Vue.js, Tailwind CSS e outras ferramentas modernas. Foco em criar soluções espráticas para a web.</p>
          </div>
        </div>
        <div class="flex items-center justify-between">
          <div class="flex-1 p-6 bg-white shadow-md rounded-lg">
            <h3 class="font-semibold text-xl">Estágio em Desenvolvimento Web</h3>
            <p class="text-gray-700">Startup ABC - Jan 2021 - Janeiro 2025</p>
            <p class="mt-4">Durante o estágio, trabalhei com HTML, CSS e JavaScript para a criação de sites e aplicações interativas, com foco em melhorar a experiência do usuário.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="py-16 px-4 bg-blue-600 text-white text-center">
      <h2 class="text-3xl font-semibold mb-4">Gostou do meu trabalho?</h2>
      <p class="text-lg mb-6">Vamos conversar sobre como posso ajudar no seu próximo projeto!</p>
      <router-link to="/contato" class="bg-blue-800 text-white py-3 px-8 rounded hover:bg-blue-700">Fale comigo</router-link>
    </section>
  </div>
</template>

<script setup>

</script>