<template>
  <div class="max-w-xl mx-auto p-4">
    <h2 class="text-2xl font-semibold mb-4">Entre em Contato</h2>

    <!-- Formulário de Contato (Não funcional) -->
    <form class="flex flex-col gap-4">
      <input class="border p-2 rounded" type="text" placeholder="Seu nome" />
      <input class="border p-2 rounded" type="email" placeholder="Seu e-mail" />
      <textarea class="border p-2 rounded" rows="4" placeholder="Sua mensagem"></textarea>
      <button class="bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Enviar</button>
    </form>

    <!-- Informações de Contato -->
    <div class="mt-8">
      <p class="font-semibold mb-2">Meus contatos:</p>
      <ul class="text-sm text-gray-700">
        <li>Email: <a href="mailto:seunome@email.com" class="text-blue-500 hover:underline">jpgoncalves@gmail.com</a></li>
        <li>Telefone: <a href="tel:+1234567890" class="text-blue-500 hover:underline">+55 (14) 99701-2723</a></li>
      </ul>
    </div>

    <!-- Redes Sociais -->
    <div class="mt-8">
      <p class="font-semibold mb-2">Siga-me nas redes sociais:</p>
      <ul class="flex gap-4 text-blue-500">
        <li><a href="https://www.linkedin.com/in/seunome" target="_blank" class="hover:underline">LinkedIn</a></li>
        <li><a href="https://github.com/seunome" target="_blank" class="hover:underline">GitHub</a></li>
        <li><a href="https://www.twitter.com/seunome" target="_blank" class="hover:underline">Twitter</a></li>
      </ul>
    </div>
  </div>
</template>

<script setup>
// Nenhuma lógica adicional para o momento
</script>
