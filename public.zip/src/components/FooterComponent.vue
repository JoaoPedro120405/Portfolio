<template>
    <footer class="bg-gray-800 text-white text-center py-4 mt-8">
      <p>&copy; 2025 João Pedro. Todos os direitos reservados.</p>
    </footer>
  </template>
  
  <script setup>
 
  </script>